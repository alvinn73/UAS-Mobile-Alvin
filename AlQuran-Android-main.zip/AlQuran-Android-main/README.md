# Al-Quran-Android
SOURCE CODE APLIKASI AL-QURAN DENGAN ANDROID STUDIO

Source Code ini sudah di update. Untuk source code versi lama, silahkan lihat di Youtube https://youtu.be/NKzhWqA9lDw

Berikut Update-nya :
- FAN (Fast Android Networking) -> Retrofit
- Java -> Kotlin
- MVP -> MVVM
- Pembaruan Maps Pencarian Masjid
- Update Library with Android Studio Arctic Fox | 2020.3.1
- DEMO APLIKASI https://youtu.be/SMYpSk_GHKo

# Tutorial Build with Step by Step
https://rivaldi48.blogspot.com/2019/04/tutorial-membuat-aplikasi-al-quran.html

<img src="https://1.bp.blogspot.com/-C_ePRhy5l-Y/XxfcDJ-a7PI/AAAAAAAAHdc/T-tH3K8NuuUW09Ti-Hwl8umXZFKElx5agCLcBGAsYHQ/s1600/HiShoot_20200722_131945.png" data-canonical-src="https://1.bp.blogspot.com/-C_ePRhy5l-Y/XxfcDJ-a7PI/AAAAAAAAHdc/T-tH3K8NuuUW09Ti-Hwl8umXZFKElx5agCLcBGAsYHQ/s1600/HiShoot_20200722_131945.png" style="max-width:100%;">

<img src="https://1.bp.blogspot.com/-h0Zx3gIvI3s/XxfcFj4lk7I/AAAAAAAAHdg/coTm9i9K5O8CkyoZAaIgGf8YYw7N2JqfACLcBGAsYHQ/s1600/HiShoot_20200722_132001.png" data-canonical-src="https://1.bp.blogspot.com/-h0Zx3gIvI3s/XxfcFj4lk7I/AAAAAAAAHdg/coTm9i9K5O8CkyoZAaIgGf8YYw7N2JqfACLcBGAsYHQ/s1600/HiShoot_20200722_132001.png" style="max-width:100%;">

*****If you use the Source Code, please make sure to credit and backlink to [Azhar Rivaldi](https://rivaldi48.blogspot.com/)***

## 👇 Click For Support Me :
<a href="https://sociabuzz.com/azharrvldi_/donate"> 
<img src="https://github.com/AzharRivaldi/AzharRivaldi/blob/master/Support%20Here.png" width="200" height="200"></a>

## 📄 License

```
Copyright (C) Azhar Rivaldi

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.

```
